# P. SriShanth's Online Movie Ticket Booking System

## Project description
Manage movies, theatres, and ticket bookings. Customers can view available movies, check show timings, select seats, and book tickets.

## Technologies
- Frontend: HTML, CSS, JavaScript
- Backend: Node.js and Express.js
- Database: MySQL
- Version control: Git and GitHub

## Database tables
1. `theatres` — theatre_id, theatre_name, location, screen_name
2. `movies` — movie_id, title, genre, language, duration, rating, description, poster_url, release_date
3. `shows` — show_id, movie_id, theatre_id, show_date, show_time, price, total_seats, available_seats
4. `bookings` — booking_id, show_id, customer_name, customer_email, seats, total_amount, booking_status, booked_at

## Setup
1. Install Node.js and MySQL.
2. Open MySQL Workbench and run `database.sql`.
3. Open this project folder in VS Code.
4. Run `npm install`.
5. Copy `.env.example` to `.env` and enter your MySQL password.
6. Run `npm start`.
7. Open `http://localhost:3000`.

## GitHub upload
Create a new empty GitHub repository, then run these commands in the project folder:

```bash
git init
git add .
git commit -m "Initial movie ticket booking system"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Do not upload `.env` or your database password. The `.gitignore` file excludes `.env` and `node_modules`.

## Notes
This is a mini-project starter implementation. Demo movie posters use remote image URLs and require internet access. Booking requests are validated on the server and seat availability is updated in a MySQL transaction.
