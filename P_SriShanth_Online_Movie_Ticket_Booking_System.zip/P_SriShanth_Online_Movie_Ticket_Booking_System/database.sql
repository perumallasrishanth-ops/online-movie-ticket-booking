CREATE DATABASE IF NOT EXISTS srishanth_movie_booking;
USE srishanth_movie_booking;

CREATE TABLE IF NOT EXISTS theatres (
  theatre_id INT AUTO_INCREMENT PRIMARY KEY,
  theatre_name VARCHAR(120) NOT NULL,
  location VARCHAR(180) NOT NULL,
  screen_name VARCHAR(50) DEFAULT 'Screen 1'
);

CREATE TABLE IF NOT EXISTS movies (
  movie_id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  genre VARCHAR(80) NOT NULL,
  language VARCHAR(50) NOT NULL,
  duration INT NOT NULL COMMENT 'Duration in minutes',
  rating DECIMAL(2,1) DEFAULT 0.0,
  description TEXT,
  poster_url VARCHAR(500),
  release_date DATE
);

CREATE TABLE IF NOT EXISTS shows (
  show_id INT AUTO_INCREMENT PRIMARY KEY,
  movie_id INT NOT NULL,
  theatre_id INT NOT NULL,
  show_date DATE NOT NULL,
  show_time TIME NOT NULL,
  price DECIMAL(8,2) NOT NULL,
  total_seats INT NOT NULL DEFAULT 60,
  available_seats INT NOT NULL DEFAULT 60,
  CONSTRAINT fk_shows_movie FOREIGN KEY (movie_id) REFERENCES movies(movie_id),
  CONSTRAINT fk_shows_theatre FOREIGN KEY (theatre_id) REFERENCES theatres(theatre_id)
);

CREATE TABLE IF NOT EXISTS bookings (
  booking_id INT AUTO_INCREMENT PRIMARY KEY,
  show_id INT NOT NULL,
  customer_name VARCHAR(100) NOT NULL,
  customer_email VARCHAR(150) NOT NULL,
  seats JSON NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  booking_status ENUM('CONFIRMED','CANCELLED') DEFAULT 'CONFIRMED',
  booked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_bookings_show FOREIGN KEY (show_id) REFERENCES shows(show_id)
);

INSERT INTO theatres (theatre_name, location, screen_name) VALUES
('Galaxy Cinemas', 'Main Road, Kurnool', 'Screen 1'),
('Royal Multiplex', 'N.R. Peta, Kurnool', 'Screen 2');

INSERT INTO movies (title,genre,language,duration,rating,description,poster_url,release_date) VALUES
('The Last Horizon','Sci-Fi / Adventure','English',132,8.4,'A thrilling journey beyond the edge of the known world.','https://images.unsplash.com/photo-1440404653325-ab127d49&fit=crop&w=800&q=80','2026-10-16'),
('Midnight Run','Action / Thriller','English',118,7.9,'One night. One mission. No second chances.','https://images.unsplash.com/photo-1489599849927-2ee91a3b3d?auto=format&fit=crop&w=800&q=80','2026-10-22'),
('City of Dreams','Drama','Telugu',145,8.1,'An emotional story of ambition, friendship and second chances.','https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=800&q=80','2026-10-30');

INSERT INTO shows (movie_id,theatre_id,show_date,show_time,price,total_seats,available_seats) VALUES
(1,1,CURDATE(),'10:30:00',180,60,60),(1,1,CURDATE(),'18:30:00',220,60,60),
(2,2,CURDATE(),'13:00:00',200,60,60),(2,2,CURDATE(),'20:00:00',240,60,60),
(3,1,DATE_ADD(CURDATE(),INTERVAL 1 DAY),'16:00:00',190,60,60);
