const movieGrid = document.getElementById("movieGrid");
const showList = document.getElementById("showList");
const showSelect = document.getElementById("showSelect");
const seatMap = document.getElementById("seatMap");
const seatCount = document.getElementById("seatCount");
const totalAmount = document.getElementById("totalAmount");
const bookingMessage = document.getElementById("bookingMessage");
let movies = [], shows = [], selectedSeats = [], activeShow = null;

const money = n => "₹" + Number(n).toFixed(2);
const dateLabel = d => new Date(d + "T00:00:00").toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"});

async function loadData(){
  try{
    const [mr,sr] = await Promise.all([fetch("/api/movies"),fetch("/api/shows")]);
    if(!mr.ok || !sr.ok) throw new Error("Server could not load data. Check your database setup.");
    movies = await mr.json(); shows = await sr.json();
    renderMovies(); renderShows(); populateShowSelect();
  }catch(e){
    movieGrid.innerHTML = `<p class="loading">${e.message}</p>`;
    showList.innerHTML = `<p class="loading">Please start the Express server and configure MySQL.</p>`;
  }
}
function renderMovies(){
  movieGrid.innerHTML = movies.length ? movies.map(m=>`
    <article class="movie-card">
      <div class="movie-poster" style="background-image:url('${escapeHtml(m.poster_url || "")}')"><span class="movie-rating">★ ${m.rating || "New"}</span></div>
      <div class="movie-info"><h3>${escapeHtml(m.title)}</h3><div class="movie-meta">${escapeHtml(m.genre)} · ${escapeHtml(m.language)} · ${m.duration} MIN</div>
      <p>${escapeHtml(m.description || "Discover this movie on the big screen.")}</p>
      <button class="text-btn" onclick="chooseMovie(${m.movie_id})">BOOK THIS MOVIE →</button></div>
    </article>`).join("") : '<p class="loading">No movies found. Add movie records to the movies table.</p>';
}
function renderShows(){
  showList.innerHTML = shows.length ? shows.map(s=>`
    <article class="show-card"><div><h3>${escapeHtml(s.title)}</h3><small>${escapeHtml(s.theatre_name)} · ${escapeHtml(s.location)}</small></div>
    <div class="show-time">${dateLabel(s.show_date)}<br><small>${String(s.show_time).slice(0,5)}</small></div>
    <div class="show-price">${money(s.price)} <small>· ${s.available_seats} seats left</small></div>
    <button onclick="chooseShow(${s.show_id})">SELECT SHOW →</button></article>`).join("") : '<p class="loading">No upcoming shows available.</p>';
}
function populateShowSelect(){
  showSelect.innerHTML = '<option value="">Select movie & showtime</option>' + shows.map(s=>
    `<option value="${s.show_id}">${escapeHtml(s.title)} · ${escapeHtml(s.theatre_name)} · ${dateLabel(s.show_date)} ${String(s.show_time).slice(0,5)} · ${money(s.price)}</option>`).join("");
}
function chooseMovie(id){
  const s=shows.find(x=>x.movie_id===id);
  if(s) chooseShow(s.show_id);
  else {document.getElementById("booking").scrollIntoView({behavior:"smooth"}); bookingMessage.textContent="No upcoming show is listed for this movie yet.";bookingMessage.className="booking-message error";}
}
function chooseShow(id){
  showSelect.value=String(id); activeShow=shows.find(s=>s.show_id===id); selectedSeats=[];
  renderSeats(); updateTotal(); bookingMessage.textContent="";
  document.getElementById("booking").scrollIntoView({behavior:"smooth"});
}
function renderSeats(){
  if(!activeShow){seatMap.innerHTML='<p class="muted">Select a show to view available seats.</p>';return;}
  // A simplified demo seat layout. Confirmed bookings are used to prevent duplicate seats on the server.
  seatMap.innerHTML=Array.from({length:60},(_,i)=>{
    const row=String.fromCharCode(65+Math.floor(i/10)), seat=row+(i%10+1);
    return `<button type="button" class="seat" data-seat="${seat}" aria-label="Seat ${seat}">${seat}</button>`;
  }).join("");
  seatMap.querySelectorAll(".seat").forEach(btn=>btn.addEventListener("click",()=>{
    const seat=btn.dataset.seat;
    if(selectedSeats.includes(seat)) selectedSeats=selectedSeats.filter(x=>x!==seat);
    else if(selectedSeats.length<8) selectedSeats.push(seat);
    else {bookingMessage.textContent="You can select up to 8 seats per booking.";bookingMessage.className="booking-message error";}
    btn.classList.toggle("selected",selectedSeats.includes(seat));updateTotal();
  }));
}
function updateTotal(){seatCount.textContent=`${selectedSeats.length} selected`;totalAmount.textContent=activeShow?money(activeShow.price*selectedSeats.length):"₹0";}
showSelect.addEventListener("change",()=>{if(showSelect.value) chooseShow(Number(showSelect.value));else{activeShow=null;selectedSeats=[];renderSeats();updateTotal();}});
document.getElementById("bookingForm").addEventListener("submit",async e=>{
  e.preventDefault();bookingMessage.className="booking-message";bookingMessage.textContent="";
  if(!activeShow || !selectedSeats.length){bookingMessage.textContent="Please select a show and at least one seat.";bookingMessage.classList.add("error");return;}
  const payload={show_id:activeShow.show_id,customer_name:document.getElementById("customerName").value,customer_email:document.getElementById("customerEmail").value,seats:selectedSeats};
  try{
    const response=await fetch("/api/bookings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
    const result=await response.json();if(!response.ok)throw new Error(result.error);
    bookingMessage.textContent=`${result.message} Booking ID: #${result.booking_id}. Seats: ${result.seats.join(", ")}. Total: ${money(result.total_amount)}.`;
    bookingMessage.classList.add("success");selectedSeats=[];await loadData();activeShow=shows.find(s=>s.show_id===payload.show_id);showSelect.value=String(payload.show_id);renderSeats();updateTotal();
  }catch(err){bookingMessage.textContent=err.message;bookingMessage.classList.add("error");}
});
function escapeHtml(value){return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
loadData();
