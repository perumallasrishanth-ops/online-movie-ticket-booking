require("dotenv").config();
const express = require("express");
const path = require("path");
const db = require("./db");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/movies", async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT m.*, COUNT(DISTINCT s.show_id) AS show_count
       FROM movies m LEFT JOIN shows s ON s.movie_id=m.movie_id
       GROUP BY m.movie_id ORDER BY m.movie_id DESC`
    );
    res.json(rows);
  } catch (e) { res.status(500).json({ error: "Could not load movies." }); }
});

app.get("/api/shows", async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT s.show_id,s.show_date,s.show_time,s.price,s.total_seats,s.available_seats,
       m.movie_id,m.title,m.language,m.duration,theatre.theatre_id,theatre.theatre_name,theatre.location
       FROM shows s JOIN movies m ON s.movie_id=m.movie_id
       JOIN theatres theatre ON s.theatre_id=theatre.theatre_id
       WHERE s.show_date >= CURDATE()
       ORDER BY s.show_date,s.show_time`
    );
    res.json(rows);
  } catch (e) { res.status(500).json({ error: "Could not load show timings." }); }
});

app.post("/api/bookings", async (req, res) => {
  const { show_id, customer_name, customer_email, seats } = req.body;
  if (!show_id || !customer_name || !customer_email || !Array.isArray(seats) || !seats.length)
    return res.status(400).json({ error: "Please complete all booking details and select seats." });

  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const [showRows] = await connection.query("SELECT price,total_seats,available_seats FROM shows WHERE show_id=? FOR UPDATE", [show_id]);
    if (!showRows.length) throw new Error("Show not found.");
    const show = showRows[0];
    const [takenRows] = await connection.query(
      "SELECT seats FROM bookings WHERE show_id=? AND booking_status='CONFIRMED' FOR UPDATE", [show_id]
    );
    const taken = takenRows.flatMap(r => JSON.parse(r.seats));
    const uniqueSeats = [...new Set(seats)];
    if (uniqueSeats.length !== seats.length || uniqueSeats.some(s => taken.includes(s)))
      throw new Error("One or more selected seats are no longer available. Please choose again.");
    if (uniqueSeats.length > show.available_seats) throw new Error("Not enough seats are available.");
    const total = Number(show.price) * uniqueSeats.length;
    const [result] = await connection.query(
      `INSERT INTO bookings (show_id,customer_name,customer_email,seats,total_amount,booking_status)
       VALUES (?,?,?,?,?,'CONFIRMED')`,
      [show_id, customer_name.trim(), customer_email.trim(), JSON.stringify(uniqueSeats), total]
    );
    await connection.query("UPDATE shows SET available_seats=available_seats-? WHERE show_id=?", [uniqueSeats.length, show_id]);
    await connection.commit();
    res.status(201).json({ message: "Booking confirmed!", booking_id: result.insertId, total_amount: total, seats: uniqueSeats });
  } catch (e) {
    await connection.rollback();
    res.status(400).json({ error: e.message || "Booking could not be completed." });
  } finally { connection.release(); }
});

app.get("/api/health", (req, res) => res.json({ status: "ok" }));
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`P. SriShanth's Movie Booking System running at http://localhost:${PORT}`));
